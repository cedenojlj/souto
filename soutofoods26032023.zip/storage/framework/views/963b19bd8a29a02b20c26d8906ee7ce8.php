<div>
        
    <h5><?php echo e(Auth::user()->name); ?></h5>  

                            
               <?php if($mensajex): ?>


                    <?php if($mierror): ?>

                            <div class="alert alert-danger" role="alert">
                                <?php echo e($mensajex); ?>

                            </div> 
                    
                        <?php else: ?>

                            <div class="alert alert-success" role="alert">
                                <?php echo e($mensajex); ?>

                            </div> 
                    
                        <?php endif; ?>   

                   
               <?php endif; ?>

              <?php if($mostrarCheckout): ?>

                <div class="row mt-2">

                    <div class="col">

                        <a class="btn btn-primary" href="<?php echo e(route('checkout')); ?>">Checkout</a>

                    </div>

                </div>
                  
              <?php endif; ?>
               
            

            

            <div class="table-responsive">

                <table class="table table-sm">

                    <thead>
                        <tr>
                            <th scope="col">Order Qty</th>
                            <th scope="col">Item Number</th>
                            <th scope="col">Description</th>
                            <th scope="col">Scan Item UPC</th>
                            <th scope="col">Cases per Pallet</th>
                            <th scope="col">Food Show Deal</th>
                            <th scope="col">Notes</th>
                            <th scope="col">Final Price</th>
                            <th scope="col"><?php echo e(Auth::user()->date1); ?></th>
                            <th scope="col"><?php echo e(Auth::user()->date2); ?></th>
                            <th scope="col"><?php echo e(Auth::user()->date3); ?></th>  
                            <th scope="col">Actions</th>                             
                        </tr>
                    </thead>
                    <tbody>
    
                       
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
                       
                       

                        <tr class="<?php echo e(empty($indicador[$product->id]) ? '': $indicador[$product->id]); ?>"> 
                            
                            
    
                                
    
                               
                       
                                <td>
                                    <input wire:model="amount.<?php echo e($product->id); ?>" 
                                    id="amount" type="text" 
                                    class="form-control <?php $__errorArgs = ['amount.'.$product->id];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                    name="amount" required autofocus>
                                    
                                    <span class="error">
                                        <?php $__errorArgs = ['amount.'.$product->id];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
    
                                    
                                    
                                </td>
                                <td><?php echo e($product->itemnumber); ?></td>
                                <td><?php echo e($product->description); ?></td>
                                <td><?php echo e($product->upc); ?></td>
                                <td><?php echo e($product->pallet); ?></td>
                                <td><?php echo e($product->price); ?></td>
    
    
                                <td><input wire:model="notes.<?php echo e($product->id); ?>" 
                                    id="notes" type="text" 
                                    class="form-control <?php $__errorArgs = ['notes.'.$product->id];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="notes" >
                                
                                    <span class="error">
                                        <?php $__errorArgs = ['notes.'.$product->id];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                
                                </td>
    
    
                                <td><?php echo e(!empty($notes[$product->id])? $product->price - $notes[$product->id] :$product->price); ?></td>
    
                        
                                <td><input wire:model="qtyone.<?php echo e($product->id); ?>" 
                                    id="qtyone" type="text" 
                                    class="form-control <?php $__errorArgs = ['qtyone.'.$product->id];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="qtyone" required>
                                
                                    
                                    <span class="error">
                                        <?php $__errorArgs = ['qtyone.'.$product->id];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
    
                                </td>
                        
                                <td><input wire:model="qtytwo.<?php echo e($product->id); ?>"  
                                    id="qtytwo" type="text" 
                                    class="form-control <?php $__errorArgs = ['qtytwo.'.$product->id];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="qtytwo">
                                
                                     <span class="error">
                                        <?php $__errorArgs = ['qtytwo.'.$product->id];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
    
                                </td>
                        
                                <td><input wire:model="qtythree.<?php echo e($product->id); ?>" 
                                    id="qtythree" type="text" 
                                    class="form-control <?php $__errorArgs = ['qtythree.'.$product->id];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="qtythree">
                                
                                    <span class="error">
                                        <?php $__errorArgs = ['qtythree.'.$product->id];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
    
                                </td> 
    
                                <td> <button wire:click.prevent="incluir(<?php echo e($product->id); ?>)" type="button" class="btn btn-primary btn-sm">+</button> 
                                    <button wire:click.prevent="excluir(<?php echo e($product->id); ?>)" type="button" class="btn btn-danger btn-sm">-</button> </th>    
                                   
                        
                        
                        </tr> 
    
                         
    
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                           
                        
                    </tbody>

                </table>

            </div>

            


</div>


<?php /**PATH C:\xampp\htdocs\soutofoods\resources\views/livewire/product-container.blade.php ENDPATH**/ ?>