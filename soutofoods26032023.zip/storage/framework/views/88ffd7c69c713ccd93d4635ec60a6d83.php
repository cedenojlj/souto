<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

             

            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('product-container')->html();
} elseif ($_instance->childHasBeenRendered('YbCptzl')) {
    $componentId = $_instance->getRenderedChildComponentId('YbCptzl');
    $componentTag = $_instance->getRenderedChildComponentTagName('YbCptzl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YbCptzl');
} else {
    $response = \Livewire\Livewire::mount('product-container');
    $html = $response->html();
    $_instance->logRenderedChild('YbCptzl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\soutofoods\resources\views/homeNew.blade.php ENDPATH**/ ?>