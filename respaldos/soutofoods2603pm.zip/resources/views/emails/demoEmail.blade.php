<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Siproced</title>
</head>
<body>

    <h1>{{$emailData['title']}}</h1>

    <p>{{$emailData['body']}}</p>

    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Est 
        praesentium reprehenderit pariatur minima consectetur ea quae, 
        asperiores deleniti eius! Veritatis numquam adipisci dolor nulla. 
        Obcaecati dolore earum possimus hic corrupti.</p>

    <p>Thank you</p>
    
</body>
</html>