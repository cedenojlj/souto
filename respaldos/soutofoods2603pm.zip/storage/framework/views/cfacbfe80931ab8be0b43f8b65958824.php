<div> 
           

            <td><input wire:model="amount" id="amount" type="text" class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="amount" required autofocus></td>
            <td><?php echo e($product->itemnumber); ?></td>
            <td><?php echo e($product->description); ?></td>
            <td><?php echo e($product->upc); ?></td>
            <td><?php echo e($product->pallet); ?></td>
            <td><?php echo e($product->price); ?></td>
            <td><input wire:model="notes" id="notes" type="text" step="0.01" class="form-control <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="notes" ></td>
            <td><?php echo e($finalprice); ?></td>
    
            <td><input wire:model="qtyone" id="qtyone" type="text" class="form-control <?php $__errorArgs = ['qtyone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="qtyone" required></td>
    
            <td><input wire:model="qtytwo"  id="qtytwo" type="text" class="form-control <?php $__errorArgs = ['qtytwo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="qtytwo"></td>
    
            <td><input wire:model="qtythree" id="qtythree" type="text" class="form-control <?php $__errorArgs = ['qtythree'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="qtythree"></td> 

            <td> <button wire:click.prevent="incluir(<?php echo e($product->id); ?>)" type="button" class="btn btn-primary btn-sm">+</button> 
                <button wire:click.prevent="excluir(<?php echo e($product->id); ?>)" type="button" class="btn btn-danger btn-sm">-</button> </th>    
</div>

<?php /**PATH C:\xampp\htdocs\soutofoods\resources\views/livewire/product-item.blade.php ENDPATH**/ ?>