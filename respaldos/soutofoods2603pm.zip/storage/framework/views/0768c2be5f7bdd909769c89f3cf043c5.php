<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header"><?php echo e(__('Checkout')); ?></div>

                <div class="card-body">                        
                    
                    <h5><?php echo e(Auth::user()->name); ?></h5>
                    
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('check-out', [])->html();
} elseif ($_instance->childHasBeenRendered('8bkqeGr')) {
    $componentId = $_instance->getRenderedChildComponentId('8bkqeGr');
    $componentTag = $_instance->getRenderedChildComponentTagName('8bkqeGr');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('8bkqeGr');
} else {
    $response = \Livewire\Livewire::mount('check-out', []);
    $html = $response->html();
    $_instance->logRenderedChild('8bkqeGr', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\soutofoods\resources\views/checkout.blade.php ENDPATH**/ ?>