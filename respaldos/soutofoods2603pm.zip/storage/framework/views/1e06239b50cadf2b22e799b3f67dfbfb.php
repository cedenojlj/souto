<div>

     
    <div class="row mb-4">

        <label for="name" class="col-md-8 col-form-label text-md-end">Search:</label>

        <div class="col-md-4">
            
           <input wire:model="search" class="form-control" type="text" placeholder="Search products..."/>            
           
        </div>
    </div>

    <table class="table">
        <thead>
          <tr>            
            <th scope="col">Product</th>
            <th scope="col">UPC</th>
            <th scope="col">Cases</th>
            <th scope="col">Price</th>
            <th scope="col">Actions</th>
          </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
           
              <tr>
                
                <td><?php echo e($product->name); ?></td>
                <td><?php echo e($product->upc); ?></td>
                <td><?php echo e($product->pallet); ?></td>
                <td><?php echo e('$ '. $product->price); ?></td>
                <td><a href="<?php echo e(route('addtocart', ['product'=> $product])); ?>" class="btn btn-primary btn-sm">+</a></td>
                
              </tr>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

        </tbody>

    </table>

                
        <?php echo e($productos->links()); ?>

    

</div>


<?php /**PATH C:\xampp\htdocs\soutofoods\resources\views/livewire/product-lists.blade.php ENDPATH**/ ?>