<div>
   
    
    <div class="row mb-3">

        <label for="search" class="col-md-8 col-form-label text-md-end">Search:</label>

        <div class="col-md-4">
            
           <input wire:model="search" class="form-control" type="text" placeholder="Search products..."/>            
           
        </div>
    </div>

 
      
            
            

           

                <div class="card mb-3">
                    <div class="card-body">
                        
                        <table class="table">
                            <thead>
                              <tr>
                                <th scope="col">#</th>
                                <th scope="col">Created</th>
                                <th scope="col">Total $</th>
                                <th scope="col">Actions</th>
                              </tr>
                            </thead>
                            <tbody>

                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                              <tr>
                                <th scope="row"><?php echo e($order->id); ?></th>
                                <td><?php echo e($order->created_at->format('mdyhis')); ?></td>
                                <td><?php echo e($order->total); ?></td>
                                <td>
                                    <a href="<?php echo e(url('export-order',[$order->id])); ?>" class="btn btn-primary">Download</a>
                                </td>
                              </tr> 

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  

                            </tbody>
                          </table>
                    </div>
                  </div>

          

        

        <?php echo e($orders->links('pagination::bootstrap-5')); ?>

    


</div>
<?php /**PATH C:\xampp\htdocs\soutofoods\resources\views/livewire/order-list.blade.php ENDPATH**/ ?>