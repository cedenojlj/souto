<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('name')); ?>

            <?php echo e(Form::text('name', $customer->name, ['class' => 'form-control' . ($errors->has('name') ? ' is-invalid' : ''), 'placeholder' => 'Name'])); ?>

            <?php echo $errors->first('name', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('email')); ?>

            <?php echo e(Form::text('email', $customer->email, ['class' => 'form-control' . ($errors->has('email') ? ' is-invalid' : ''), 'placeholder' => 'Email'])); ?>

            <?php echo $errors->first('email', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

        <div class="form-group">
            <?php echo e(Form::label('email2')); ?>

            <?php echo e(Form::text('email2', $customer->email2, ['class' => 'form-control' . ($errors->has('email2') ? ' is-invalid' : ''), 'placeholder' => 'Email2'])); ?>

            <?php echo $errors->first('email2', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

        <div class="form-group">
            <?php echo e(Form::label('emailRep')); ?>

            <?php echo e(Form::text('emailRep', $customer->emailRep, ['class' => 'form-control' . ($errors->has('emailRep') ? ' is-invalid' : ''), 'placeholder' => 'EmailRep'])); ?>

            <?php echo $errors->first('emailRep', '<div class="invalid-feedback">:message</div>'); ?>

        </div>       

        <div class="form-group">
            <?php echo e(Form::label('pin')); ?>

            <?php echo e(Form::text('pin', $customer->pin, ['class' => 'form-control' . ($errors->has('pin') ? ' is-invalid' : ''), 'placeholder' => 'Pin'])); ?>

            <?php echo $errors->first('pin', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\soutofoods\resources\views/customer/form.blade.php ENDPATH**/ ?>