<div>

    <?php if($errores): ?>

        <div class="alert alert-danger" role="alert">

            <?php echo e($errores); ?>


        </div>
        
    <?php endif; ?>

    

    <form wire:submit.prevent="submit">
        <?php echo csrf_field(); ?>
                
        
        <div class="row mb-3">
            <label for="amount" class="col-md-4 col-form-label text-md-end">Quantity</label>

            <div class="col-md-6">
                <input wire:model="amount" id="amount" type="number" class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="amount" required autocomplete="amount" autofocus>

                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        
        
        <div class="row mb-3">
            <label class="col-md-4 col-form-label text-md-end">Price</label>

            <div class="col-md-6">               
                
                <p class="form-control"> <?php echo e($product->price); ?></p>

            </div>
        </div>

        

        <div class="row mb-3">
            <label for="notes" class="col-md-4 col-form-label text-md-end">Notes</label>

            <div class="col-md-6">
                <input wire:model="notes" id="notes" type="number" step="0.01" class="form-control <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="notes"  autocomplete="notes" autofocus>

                <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        
        
        <div class="row mb-3">

            <label class="col-md-4 col-form-label text-md-end">Finalprice</label>

            <div class="col-md-6">               
                
                <p class="form-control"> <?php echo e($finalprice); ?></p>
                
            </div>
        </div>

         
         

         <div class="row mb-3">
            
            <label class="col-md-4 col-form-label text-md-end">Subtotal</label>

            <div class="col-md-6">               
                
                <p class="form-control"> <?php echo e($subtotal); ?></p>
                
            </div>
        </div>

        

        
        <div class="row mb-3">
            <label for="qtyone" class="col-md-4 col-form-label text-md-end"><?php echo e($date1); ?></label>

            <div class="col-md-6">
                <input wire:model="qtyone" id="qtyone" type="number" class="form-control <?php $__errorArgs = ['qtyone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="qtyone" required autocomplete="qtyone" autofocus>

                <?php $__errorArgs = ['qtyone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        
        <div class="row mb-3">
            <label for="qtytwo" class="col-md-4 col-form-label text-md-end"><?php echo e($date2); ?></label>

            <div class="col-md-6">
                <input wire:model="qtytwo"  id="qtytwo" type="number" class="form-control <?php $__errorArgs = ['qtytwo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="qtytwo" value="<?php echo e(old('qtytwo')); ?>" autocomplete="qtytwo" autofocus>

                <?php $__errorArgs = ['qtytwo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        
        <div class="row mb-3">
            <label for="qtythree" class="col-md-4 col-form-label text-md-end"><?php echo e($date3); ?></label>

            <div class="col-md-6">
                <input wire:model="qtythree" id="qtythree" type="number" class="form-control <?php $__errorArgs = ['qtythree'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="qtythree" value="<?php echo e(old('qtythree')); ?>" autocomplete="qtythree" autofocus>

                <?php $__errorArgs = ['qtythree'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
              

        

        <div class="row mb-0">
            <div class="col-md-6 offset-md-4">
                <button type="submit" class="btn btn-primary">
                   Add to Cart
                </button>
            </div>
        </div>
    </form>


    
</div>
<?php /**PATH C:\xampp\htdocs\soutofoods\resources\views/livewire/cart-item.blade.php ENDPATH**/ ?>