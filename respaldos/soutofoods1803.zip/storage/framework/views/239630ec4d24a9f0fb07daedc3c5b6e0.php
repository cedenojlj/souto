<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(session('errores')): ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo e(session('errores')); ?>

                    </div>
                <?php endif; ?>

                    

                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cart-list', [])->html();
} elseif ($_instance->childHasBeenRendered('ckhaO5f')) {
    $componentId = $_instance->getRenderedChildComponentId('ckhaO5f');
    $componentTag = $_instance->getRenderedChildComponentTagName('ckhaO5f');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ckhaO5f');
} else {
    $response = \Livewire\Livewire::mount('cart-list', []);
    $html = $response->html();
    $_instance->logRenderedChild('ckhaO5f', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\soutofoods\resources\views/cartlist.blade.php ENDPATH**/ ?>