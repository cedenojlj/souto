<?php return array (
  'cart-item' => 'App\\Http\\Livewire\\CartItem',
  'cart-list' => 'App\\Http\\Livewire\\CartList',
  'check-out' => 'App\\Http\\Livewire\\CheckOut',
  'order-list' => 'App\\Http\\Livewire\\OrderList',
  'product-lists' => 'App\\Http\\Livewire\\ProductLists',
);