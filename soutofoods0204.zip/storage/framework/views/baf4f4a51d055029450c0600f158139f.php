<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Siproced</title>
</head>
<body>


    <h3><?php echo e($emailData['title']); ?></h3>

    <h3><?php echo e('Date: ' . $emailData['dateOrder']); ?></h3>

    <h3><?php echo e('Customer: ' . $emailData['customer']); ?></h3>


    <p>We have received your order and it will be processed very soon.</p>

    <p>Thank you</p>
    
</body>
</html>

<?php /**PATH C:\xampp\htdocs\soutofoods\resources\views/emails/demoEmail.blade.php ENDPATH**/ ?>