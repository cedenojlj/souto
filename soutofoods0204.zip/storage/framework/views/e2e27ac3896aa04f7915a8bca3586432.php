<div>

    <?php if($status): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e($status); ?>

        </div>
    <?php endif; ?>     

    <?php if($errores): ?>

        <div class="alert alert-danger" role="alert">

            <?php echo e($errores); ?>


        </div>
        
    <?php endif; ?>

    <div class="text-center">
         <div wire:loading.inline-flex wire:target="submit">       

            <button class="btn btn-primary" type="button" disabled>
                <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                Processing...
            </button>
            
        </div>
    </div>  

    <div class="Container">

       <?php if(!$general): ?>           
      
            

            <div class="row mb-4" wire:loading.remove wire:target="submit">           

                <div class="col-md-6">                
                    
                    <input type="text" class="col form-control" wire:model="searchx">               
                
                </div>

                
            </div> 
               

            <form wire:submit.prevent="submit" wire:loading.remove wire:target="submit">

                <?php if(!empty($searchx)): ?>

                    

                    <div class="row mb-3">

                        <div class="col-md-6">               
                        
                                <select wire:model="idCustomer" class="form-select <?php $__errorArgs = ['idCustomer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-label="Default select example">
            
                                    <option selected>Open this select menu</option>
            
                                    <?php $__currentLoopData = $Customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
            
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                       
                                    
                                </select> 

                                <?php $__errorArgs = ['idCustomer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            
                        </div>
            
                    </div>
            
                    

                    <div class="row mb-3">                
            
                        <div class="col-md-6">
            
                            <label for="email" class="col-form-label text-md-end">Email Customer</label>
                            
                            <input wire:model="email" id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" required>
            
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    

                    <div class="row mb-3">                
            
                        <div class="col-md-6">
            
                            <label for="email2" class="col-form-label text-md-end">Email Customer</label>
                            
                            <input wire:model="email2" id="email2" type="email2" class="form-control <?php $__errorArgs = ['email2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email2" required>
            
                            <?php $__errorArgs = ['email2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    

                    <div class="row mb-3">                
            
                        <div class="col-md-6">
            
                            <label for="emailRep" class="col-form-label text-md-end">Sales Rep</label>
                            
                            <input wire:model="emailRep" id="emailRep" type="emailRep" class="form-control <?php $__errorArgs = ['emailRep'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="emailRep" required>
            
                            <?php $__errorArgs = ['emailRep'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
            
                     

                     <div class="row mb-3">                
            
                        <div class="col-md-6">
            
                            <label for="vendorEmail" class="col-form-label text-md-end">Email Vendor</label>
                            
                            <input wire:model="vendorEmail" id="vendorEmail" type="vendorEmail" class="form-control <?php $__errorArgs = ['vendorEmail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="vendorEmail" required>
            
                            <?php $__errorArgs = ['vendorEmail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                                           
                    
                    

                    <div class="row mb-3">                
            
                        <div class="col-md-6">
            
                            <label for="pin" class="col-form-label">PIN</label>
            
                            <input wire:model="pin" id="pin" type="password" class="form-control <?php $__errorArgs = ['pin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pin" required autocomplete="new-password">
            
                            <?php $__errorArgs = ['pin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div> 

                    

                    <div class="row mb-3">                
            
                        <div class="col-md-6">
            
                            <label for="rebate" class="col-form-label">Rebate</label>
            
                            <input wire:model="rebate" id="rebate" type="number" step=".01" class="form-control <?php $__errorArgs = ['rebate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="rebate" >
            
                            <?php $__errorArgs = ['rebate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>                    

                    
                    
                    <div class="row mb-3">                
            
                        <div class="col-md-6">
            
                            <label for="comments" class="col-form-label text-md-end">Comments</label>  
                            
                            <textarea wire:model="comments" class="form-control" name="comments" id="comments" rows="3"></textarea>  

                        </div>
                    </div>

                    

                    <div class="row mb-0">

                        <div class="col-md-6">

                            <button type="submit" class="btn btn-primary">Checkout</button>  

                        </div>

                    </div>
                
                <?php endif; ?>


            </form>

        <?php else: ?>

            <div class="row mt-3" wire:loading.remove wire:target="submit">

                <h5>Number Order: #<?php echo e($orderDate->format('Ymdhis')); ?></h5>
                <h5>Date Order: <?php echo e($orderDate->format('m-d-Y')); ?></h5>
               
                <h5>Total Order: <?php echo e('$ ' . $total); ?></h5>

            </div>
           
        <?php endif; ?>
       
    </div>  

    
</div>
<?php /**PATH C:\xampp\htdocs\soutofoods\resources\views/livewire/check-out.blade.php ENDPATH**/ ?>