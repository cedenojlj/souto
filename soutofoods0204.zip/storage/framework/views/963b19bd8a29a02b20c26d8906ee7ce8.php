<div>

   
        
    <h5><?php echo e(Auth::user()->name); ?></h5>  

                            
               <?php if($mensajex): ?>


                    <?php if($mierror): ?>

                            <div class="alert alert-danger" role="alert">
                                <?php echo e($mensajex); ?>

                            </div> 
                    
                        <?php else: ?>

                            <div class="alert alert-success" role="alert">
                                <?php echo e($mensajex); ?>

                            </div> 
                    
                        <?php endif; ?>   

                   
               <?php endif; ?>

             


            

            <?php if($showFormItems): ?>             

                <div class="row justify-content-center">

                    <div class="col-md-8">

                        <div class="card">
                            
                            <div class="card-header">Add Items</div>
            
                            <div class="card-body">

                                

                                <div class="row mb-3 justify-content-center">

                                    <label for="search" class="col col-md-2 col-form-label text-md-end">Search:</label>

                                    <div class="col col-md-6">
                                        
                                        <input wire:model="search" class="form-control" type="text" placeholder="Search Product code or name..."/>            
                                    
                                    </div>
                                </div>

                                
                                

                                <div class="row mb-3 justify-content-center">

                                    <label for="idProduct" class="col-md-2 col-form-label text-md-end">Product:</label>

                                    <div class="col-md-6">               
                                    
                                            <select wire:model="idProduct" class="form-select <?php $__errorArgs = ['idProduct'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-label="Default select example">
                        
                                                <option selected>Open this select menu</option>
                        
                                                <?php $__currentLoopData = $listaProductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->itemnumber.' '.$item->name); ?></option>
                        
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                       
                                                
                                            </select> 
            
                                            <?php $__errorArgs = ['idProduct'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        
                                    </div>
                        
                                </div>


                                

                                <div class="row justify-content-md-center ">


                                    <div class="col-md-1">
                    
                                    <button type="button" wire:click="saveItem" name="" id="" class="btn btn-primary">Add</button>
                                    
                    
                                    </div>

                                    <div class="col-md-1">
                    
                                        <button type="button" wire:click="closeItem" name="" id="" class="btn btn-primary">Close</button>
                        
                                    </div>

                                </div>   

                                
                            </div>
                        </div>
                    </div>
                </div>

            <?php endif; ?>
           
            
            
            <?php if($showFormItemsBundle): ?>             

                <div class="row justify-content-center mt-4">

                    <div class="col-md-8">

                        <div class="card">
                            
                            <div class="card-header">Add Bundles</div>
            
                            <div class="card-body">                               

                                
                                

                                <div class="row mb-3 justify-content-center">

                                    <label for="idProductBundle" class="col-md-2 col-form-label text-md-end">Product:</label>

                                    <div class="col-md-6">               
                                    
                                            <select wire:model="idProductBundle" class="form-select <?php $__errorArgs = ['idProductBundle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-label="Default select example">
                        
                                                <option selected>Open this select menu</option>  
                                                
                                                <option value="1">Bundle 1</option>
                                                <option value="2">Bundle 2</option>
                                                <option value="3">Bundle 3</option>
                                                <option value="4">Bundle 4</option>
                                                <option value="5">Bundle 5</option>
                                                
                                            </select> 
            
                                            <?php $__errorArgs = ['idProductBundle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        
                                    </div>
                        
                                </div>


                                

                                <div class="row justify-content-md-center ">


                                    <div class="col-md-1">
                    
                                    <button type="button" wire:click="saveItemBundle" name="" id="" class="btn btn-primary">Add</button>
                                    
                    
                                    </div>

                                    <div class="col-md-1">
                    
                                        <button type="button" wire:click="closeItemBundle" name="" id="" class="btn btn-primary">Close</button>
                        
                                    </div>

                                </div>   

                                
                            </div>
                        </div>
                    </div>
                </div>

            <?php endif; ?>
            
                

            <div class="text-center">
                <div wire:loading.inline-flex wire:target="save">

                    <button class="btn btn-primary" type="button" disabled>
                        <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                        Processing......
                    </button>
                    
                </div>
            </div>             

                
               
            <div class="row mt-4" wire:loading.remove wire:target="save">

              <div class="col-1">

                <button type="button" wire:click="save" name="" id="" class="btn btn-primary">checkout</button>

                

              </div>

              <div class="col-1">

                <button type="button" wire:click="openFormItem" name="" id="" class="btn btn-primary">AddItem</button>

              </div>

              <div class="col-1">

                <button type="button" wire:click="openFormItemBundle" name="" id="" class="btn btn-primary">Bundle</button>

              </div>


            </div>          
            

            <div class="table-responsive" wire:loading.remove wire:target="save">

                    <table class="table table-sm">

                        <thead>
                            <tr>
                                <th scope="col">Order Qty</th>
                                
                                <th scope="col">Description</th>
                                <th scope="col">Scan Item UPC</th>
                                <th scope="col">Cases per Pallet</th>
                                <th scope="col">Food Show Deal</th>
                                <th scope="col">Notes</th>
                                <th scope="col">Final Price</th>
                                 
                                <th scope="col"><?php echo e($fecha1); ?></th>
                                <th scope="col"><?php echo e($fecha2); ?></th>
                                <th scope="col"><?php echo e($fecha3); ?></th> 

                            </tr>
                        </thead>
                        <tbody>
        
                        

                            

                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => &$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
                        
                        

                            <tr class="<?php echo e(empty($indicador[$key]) ? '': $indicador[$key]); ?>"> 
                                
                                
        
                                    
        
                                
                        
                                    <td>
                                        <input wire:model="amount.<?php echo e($key); ?>" 
                                        id="amount" type="number"  
                                        class="form-control <?php $__errorArgs = ['amount.'.$key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                        name="amount" required autofocus>
                                        
                                        <span class="error">
                                            <?php $__errorArgs = ['amount.'.$key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </span>
        
                                        
                                        
                                    </td>
                                    
                                    <td><?php echo e($value['description']); ?></td>
                                    <td><?php echo e($value['upc']); ?></td>
                                    <td><?php echo e($value['pallet']); ?></td>
                                    <td><?php echo e($value['price']); ?></td>
        
        
                                    <td><input wire:model="notes.<?php echo e($key); ?>" 
                                        id="notes" type="number" 
                                        class="form-control <?php $__errorArgs = ['notes.'.$key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="notes" >
                                    
                                        <span class="error">
                                            <?php $__errorArgs = ['notes.'.$key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </span>
                                    
                                    </td>
        
        
                                    <td><?php echo e(!empty($notes[$key])? $value['price'] - $notes[$key] :$value['price']); ?></td>
        
                            
                                    <td><input wire:model="qtyone.<?php echo e($key); ?>" 
                                        id="qtyone" type="number" 
                                        class="form-control <?php $__errorArgs = ['qtyone.'.$key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="qtyone" required>
                                    
                                        
                                        <span class="error">
                                            <?php $__errorArgs = ['qtyone.'.$key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </span>
        
                                    </td>
                            
                                    <td><input wire:model="qtytwo.<?php echo e($key); ?>"  
                                        id="qtytwo" type="number" 
                                        class="form-control <?php $__errorArgs = ['qtytwo.'.$key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="qtytwo">
                                    
                                        <span class="error">
                                            <?php $__errorArgs = ['qtytwo.'.$key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </span>
        
                                    </td>
                            
                                    <td><input wire:model="qtythree.<?php echo e($key); ?>" 
                                        id="qtythree" type="number"  
                                        class="form-control <?php $__errorArgs = ['qtythree.'.$key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="qtythree">
                                    
                                        <span class="error">
                                            <?php $__errorArgs = ['qtythree.'.$key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </span>
        
                                    </td>     
                            
                            
                            </tr> 
        
                            
        
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                                                     
                            
                        </tbody>

                    </table>

            </div>

            

            
</div>


<?php /**PATH C:\xampp\htdocs\soutofoods\resources\views/livewire/product-container.blade.php ENDPATH**/ ?>