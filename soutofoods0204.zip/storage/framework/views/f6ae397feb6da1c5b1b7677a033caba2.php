

    <table class="table">
       
        <tbody>
            <tr>
                <td></td>
                <th style="font-size:16px"> <strong>Order:</strong></th>
                <td style="font-size:16px; "><strong><?php echo e($orderDate); ?></strong></td>                  
                <td></td>              
            </tr>    
            <tr>
                <td></td>
                <th style="font-size:16px; color:#fcbf43"> <strong>Customer:</strong></th>
                <td style="font-size:16px; border: 1px solid #000000;"><strong><?php echo e($customer->name); ?></strong></td>  
                <td></td>
                            
            </tr>   
            
            <tr>
                <td></td>
                <th style="font-size:16px; color:#fcbf43"> <strong>Vendor:</strong></th>
                <td style="font-size:16px; border: 1px solid #000000;"><strong><?php echo e(Auth::user()->name); ?></strong></td> 
                <td></td>                             
            </tr>   
           
        </tbody>
    </table>



<table>
    <thead>
    <tr>        
        <th style="background-color: #fcbf43;border: 1px solid #000000;"><strong>   Qty </strong>  </th>
        <th style="background-color: #999793;border: 1px solid #000000;"><strong>   Item Number </strong>  </th> 
        <th style="background-color: #999793;border: 1px solid #000000;"><strong>   Description </strong>  </th> 
        <th style="background-color: #999793;border: 1px solid #000000;"><strong>   Scan Item UPC </strong>  </th>
        <th style="background-color: #999793;border: 1px solid #000000;"><strong>   Cases per Pallet </strong>  </th>
        <th style="background-color: #999793;border: 1px solid #000000;"><strong>   Food Show Deal </strong>  </th>
        <th style="background-color: #fcbf43;border: 1px solid #000000;"><strong>   notes </strong>  </th>

        <th style="background-color: #999793;border: 1px solid #000000;"><strong>   finalprice </strong>  </th>
        <th style="background-color: #fcbf43;border: 1px solid #000000;"><strong>   <?php echo e($date1); ?> </strong>  </th>
        <th style="background-color: #fcbf43;border: 1px solid #000000;"><strong>   <?php echo e($date2); ?> </strong>  </th>
        <th style="background-color: #fcbf43;border: 1px solid #000000;"><strong>   <?php echo e($date3); ?> </strong>  </th>
    </tr>
    </thead>
    <tbody>

    
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            
            <td style="border: 1px solid #000000;" ><?php echo e($order->amount); ?></td>
            <td style="border: 1px solid #000000;"><?php echo e($order->itemnumber); ?></td> 
            <td style="border: 1px solid #000000;"><?php echo e($order->name); ?></td>  
                      

            <td style="border: 1px solid #000000;"><?php echo e($order->upc); ?></td>
            <td style="border: 1px solid #000000;"><?php echo e($order->pallet); ?></td>
            <td style="border: 1px solid #000000;"><?php echo e("$ ". $order->price); ?></td>
            <td style="border: 1px solid #000000;"><?php echo e($order->notes); ?></td>

            <td style="border: 1px solid #000000;"><?php echo e("$ ". $order->finalprice); ?></td>
            <td style="border: 1px solid #000000;"><?php echo e($order->qtyone); ?></td>
            <td style="border: 1px solid #000000;"><?php echo e($order->qtytwo); ?></td>
            <td style="border: 1px solid #000000;"><?php echo e($order->qtythree); ?></td>          
            
        </tr>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
</table>



<table class="table">
       
    <tbody>
        <tr>            
            <th style="font-size:14px"> <strong>Rebate #</strong></th>
            <td style="font-size:14px"><strong><?php echo e($orden->rebate); ?></strong></td>  
            
        </tr>    
        <tr>
            
            <th style="font-size:14px;"> <strong>Amount #</strong></th>
            <td style="font-size:14px"><strong><?php echo e("$ ". $orden->total); ?></strong></td>   
            
                        
        </tr>          
         
       
    </tbody>
</table>


<table >
       
    <tbody>
        <tr> 
            <td></td>           
            <th style="font-size:14px"> <strong>Notes:</strong></th>  
        </tr>    
        <tr>          
            <td></td>
            <td style="font-size:16px; border-bottom: 50px solid #000000;" colspan="6"><?php echo e($orden->comments); ?></td>     
                        
        </tr>    
        <tr>          
            <td></td>
            <td style="font-size:16px; border-bottom: 50px solid #000000;" colspan="6"></td>     
                        
        </tr>  
        <tr>          
            <td></td>
            <td style="font-size:16px; border-bottom: 50px solid #000000;" colspan="6"></td>     
                        
        </tr>  
        <tr>          
            <td></td>
            <td style="font-size:16px; border-bottom: 50px solid #000000;" colspan="6"></td>     
                        
        </tr>  
        <tr>          
            <td></td>
            <td style="font-size:16px; border-bottom: 50px solid #000000;" colspan="6"></td>     
                        
        </tr>  
        <tr>          
            <td></td>
            <td style="font-size:16px; border-bottom: 50px solid #000000;" colspan="6"></td>     
                        
        </tr>  

         
       
    </tbody>
</table>




<?php /**PATH C:\xampp\htdocs\soutofoods\resources\views/exports/order.blade.php ENDPATH**/ ?>