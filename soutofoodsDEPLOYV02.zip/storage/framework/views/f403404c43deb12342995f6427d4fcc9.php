<?php $__env->startSection('template_title'); ?>
    <?php echo e($product->name ?? 'Show Product'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Product</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('products.index')); ?>"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Itemnumber:</strong>
                            <?php echo e($product->itemnumber); ?>

                        </div>
                        <div class="form-group">
                            <strong>Name:</strong>
                            <?php echo e($product->name); ?>

                        </div>
                        <div class="form-group">
                            <strong>Description:</strong>
                            <?php echo e($product->description); ?>

                        </div>
                        <div class="form-group">
                            <strong>Upc:</strong>
                            <?php echo e($product->upc); ?>

                        </div>
                        <div class="form-group">
                            <strong>Pallet:</strong>
                            <?php echo e($product->pallet); ?>

                        </div>
                        <div class="form-group">
                            <strong>Price:</strong>
                            <?php echo e($product->price); ?>

                        </div>
                        <div class="form-group">
                            <strong>User Id:</strong>
                            <?php echo e($product->user_id); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\soutofoods\resources\views\product\show.blade.php ENDPATH**/ ?>