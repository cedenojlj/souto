<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(session('errores')): ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e(session('errores')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <?php
                        
                        $carrito = session('carrito');                        

                    ?>

                    <form method="POST" action="<?php echo e(route('updatecart')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                                
                        
                        <div class="row mb-3">
                            <label for="amount" class="col-md-4 col-form-label text-md-end">Quantity</label>
                
                            <div class="col-md-6">
                                <input id="amount" type="number" class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="amount" value="<?php echo e($carrito[$iditem]['amount']); ?>" required autocomplete="amount" autofocus>
                
                                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                
                        <div class="row mb-3">
                            <label class="col-md-4 col-form-label text-md-end">Price</label>
                
                            <div class="col-md-6">               
                                <p class="form-control"> <?php echo e($carrito[$iditem]['price']); ?></p>
                            </div>
                        </div>
                
                        
                        <div class="row mb-3">
                            <label for="notes" class="col-md-4 col-form-label text-md-end">Notes</label>
                
                            <div class="col-md-6">
                                <input id="notes" type="number" step="0.01" class="form-control <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="notes" value="<?php echo e(round($carrito[$iditem]['notes'],2)); ?>" autocomplete="notes" autofocus>
                
                                <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                
                        
                        <div class="row mb-3">
                            <label for="qtyone" class="col-md-4 col-form-label text-md-end">Quantity One</label>
                
                            <div class="col-md-6">
                                <input id="qtyone" type="number" class="form-control <?php $__errorArgs = ['qtyone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="qtyone" value="<?php echo e($carrito[$iditem]['qtyone']); ?>" required autocomplete="qtyone" autofocus>
                
                                <?php $__errorArgs = ['qtyone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                
                        
                        <div class="row mb-3">
                            <label for="qtytwo" class="col-md-4 col-form-label text-md-end">Quantity two</label>
                
                            <div class="col-md-6">
                                <input id="qtytwo" type="number" class="form-control <?php $__errorArgs = ['qtytwo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="qtytwo" value="<?php echo e($carrito[$iditem]['qtytwo']); ?>" autocomplete="qtytwo" autofocus>
                
                                <?php $__errorArgs = ['qtytwo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                
                        
                        <div class="row mb-3">
                            <label for="qtythree" class="col-md-4 col-form-label text-md-end">Quantity three</label>
                
                            <div class="col-md-6">
                                <input id="qtythree" type="number" class="form-control <?php $__errorArgs = ['qtythree'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="qtythree" value="<?php echo e($carrito[$iditem]['qtythree']); ?>" autocomplete="qtythree" autofocus>
                
                                <?php $__errorArgs = ['qtythree'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                              
                
                        <div class="row mb-3">
                                            
                            <div class="col-md-6">
                                <input id="product_id" type="hidden" name="product_id" value="<?php echo e($carrito[$iditem]['id']); ?>" >  
                            </div>
                        </div>
                
                        <div class="row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                   Add to Cart
                                </button>
                            </div>
                        </div>
                    </form>
                   
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\soutofoods\resources\views\addtocart\edit.blade.php ENDPATH**/ ?>