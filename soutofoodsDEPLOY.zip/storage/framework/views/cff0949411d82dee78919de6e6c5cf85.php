<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(session('errores')): ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo e(session('errores')); ?>

                    </div>
                <?php endif; ?>                    

                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('order-list', [])->html();
} elseif ($_instance->childHasBeenRendered('T7HPbQd')) {
    $componentId = $_instance->getRenderedChildComponentId('T7HPbQd');
    $componentTag = $_instance->getRenderedChildComponentTagName('T7HPbQd');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('T7HPbQd');
} else {
    $response = \Livewire\Livewire::mount('order-list', []);
    $html = $response->html();
    $_instance->logRenderedChild('T7HPbQd', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>       
                  
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\soutofoods\resources\views\orderlist.blade.php ENDPATH**/ ?>