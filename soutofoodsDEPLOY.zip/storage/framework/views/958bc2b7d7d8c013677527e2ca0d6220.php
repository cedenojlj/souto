<?php $__env->startSection('template_title'); ?>
    <?php echo e($customer->name ?? 'Show Customer'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Customer</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('customers.index')); ?>"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Name:</strong>
                            <?php echo e($customer->name); ?>

                        </div>
                        <div class="form-group">
                            <strong>Email:</strong>
                            <?php echo e($customer->email); ?>

                        </div>
                        <div class="form-group">
                            <strong>Pin:</strong>
                            <?php echo e($customer->pin); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\soutofoods\resources\views\customer\show.blade.php ENDPATH**/ ?>