<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Siproced</title>
</head>
<body>

    <h1><?php echo e($emailData['title']); ?></h1>

    <p><?php echo e($emailData['body']); ?></p>

    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Est 
        praesentium reprehenderit pariatur minima consectetur ea quae, 
        asperiores deleniti eius! Veritatis numquam adipisci dolor nulla. 
        Obcaecati dolore earum possimus hic corrupti.</p>

    <p>Thank you</p>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\soutofoods\resources\views\emails\demoEmail.blade.php ENDPATH**/ ?>