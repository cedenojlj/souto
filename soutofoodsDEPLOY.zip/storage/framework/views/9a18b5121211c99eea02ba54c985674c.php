

<h4>Order Number: <?php echo e($orden->id); ?></h4>
<h4>Customer: <?php echo e($customer->name); ?></h4>


<table>
    <thead>
    <tr>        
        <th>Qty</th>
        <th>Description</th>       

        <th>Scan Item UPC</th>
        <th>Cases per Pallet</th>
        <th>Food Show Deal</th>
        <th>notes</th>

        <th>finalprice</th>
        <th><?php echo e($orden->date1); ?></th>
        <th><?php echo e($orden->date2); ?></th>
        <th><?php echo e($orden->date3); ?></th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            
            <td><?php echo e($order->amount); ?></td>
            <td><?php echo e($order->name); ?></td>            

            <td><?php echo e($order->upc); ?></td>
            <td><?php echo e($order->pallet); ?></td>
            <td><?php echo e($order->price); ?></td>
            <td><?php echo e($order->notes); ?></td>

            <td><?php echo e($order->finalprice); ?></td>
            <td><?php echo e($order->qtyone); ?></td>
            <td><?php echo e($order->qtytwo); ?></td>
            <td><?php echo e($order->qtythree); ?></td>          
            
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<h4>Rebate: <?php echo e($orden->rebate); ?></h4>
<h4>Notes:</h4>
<p><?php echo e($orden->comments); ?></p><?php /**PATH C:\xampp\htdocs\soutofoods\resources\views\exports\order.blade.php ENDPATH**/ ?>