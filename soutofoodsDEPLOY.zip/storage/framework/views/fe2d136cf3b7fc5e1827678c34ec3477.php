<div>


    

    <div class="row mb-3">

        <label for="name" class="col-md-8 col-form-label text-md-end">Search:</label>

        <div class="col-md-4">
            
           <input wire:model="search" class="form-control" type="text" placeholder="Search products..."/>            
           
        </div>
    </div>

    <ul>
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            

            <li>

                <div class="card mb-3">
                    <div class="card-body">


                        <div class="row">
                            <div class="col">
                                <h6 class="card-title"><?php echo e($product->name); ?></h6>                                
                            </div>

                            <div class="col">                                
                                <p class="card-text"><?php echo e($product->description); ?></p>
                            </div>

                            <div class="col">
                                <h6 class="card-subtitle text-muted">Price:<?php echo e($product->price); ?></h6>
                            </div>
                            <div class="col">
                                <a href="<?php echo e(route('addtocart', ['product'=> $product])); ?>" class="btn btn-primary">Add to cart</a>
                            </div>
                        </div>
                      
                      
                     
                    </div>
                  </div>

            </li>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php echo e($productos->links('pagination::bootstrap-5')); ?>

    </ul>

</div>


<?php /**PATH C:\xampp\htdocs\soutofoods\resources\views\livewire\product-lists.blade.php ENDPATH**/ ?>