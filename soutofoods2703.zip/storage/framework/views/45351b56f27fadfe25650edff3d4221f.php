<div>
    <table class="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Product</th>
            <th scope="col">Qty</th>
            <th scope="col">Price</th>
            <th scope="col">Actions</th>
          </tr>
        </thead>
        <tbody>

            <?php

                $total=0;

            ?>


            <?php if(session('carrito')): ?>
                                    
                <?php $__currentLoopData = session('carrito'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($item['name']); ?></td>
                        <td><?php echo e($item['amount']); ?></td>
                        <td><?php echo e('$ '. $item['finalprice']); ?></td>
                        <td>

                           <form action="<?php echo e(route('cartdestroy')); ?>" method="post">

                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                                <a class="btn btn-primary" href="<?php echo e(route('editcart', $item['id'])); ?>">Edit</a>

                                <input id="idproduct" type="hidden" name="id" value="<?php echo e($item['id']); ?>">                              

                                <button type="submit" class="btn btn-danger">Delete</button>                           

                            </form>                           

                        </td>
                    </tr> 

                    <?php
                        $total=$total+ ($item['amount'] * $item['finalprice']);
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

            <?php else: ?>

                <h6>No Product in the Cart</h6>  
                              
            <?php endif; ?>     
        
      </table>

      

      <?php if($total>0): ?>

        <div class="container">

            <div class="row mt-2">
                <div class="col">

                    <h5>Total $: <?php echo e(round($total,2)); ?></h5>

                </div>
            </div>

            <div class="row mt-2">
                <div class="col">

                    <a class="btn btn-primary" href="<?php echo e(route('checkout')); ?>">Checkout</a>

                </div>
            </div>

        </div>
          
      <?php endif; ?>
      
</div>
<?php /**PATH C:\xampp\htdocs\soutofoods\resources\views/livewire/cart-list.blade.php ENDPATH**/ ?>